import React from 'react';
import { Image } from 'react-native';
import { useCart } from '../context/CartContext';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import MarqueeBanner from '../components/MarqueeBanner';
import { colors, fonts } from '../theme';

const categories = [
  { name: 'Accessories', route: 'Accessories', icon: 'watch-variant',
    desc: 'Watches, wallets, jewellery & purses', tint: '#FDE4EC', color: '#D6336C' },
  { name: 'Clothes', route: 'Clothes', icon: 'tshirt-crew-outline',
    desc: 'Stitched & unstitched for him & her', tint: '#E8E2FF', color: '#6C4BD6' },
  { name: 'Makeup', route: 'Makeup', icon: 'lipstick',
    desc: 'Fresh picks fetched live from the API', tint: '#FFF0D6', color: '#E08A00' },
];

export default function HomeScreen({ navigation }) {
    const { totalItems } = useCart();
    const { user, logout } = useAuth();

const confirmLogout = () =>
  Alert.alert('Logout', 'Do you want to logout?', [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Logout', style: 'destructive', onPress: logout },
  ]);
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.topBar}>
  <View style={{ flex: 1 }}>
    <Text style={styles.welcome} numberOfLines={1}>
      {user ? user.email : 'Welcome back'}
    </Text>
    <Text style={styles.title}>Find your style</Text>
  </View>
  <View style={{ flexDirection: 'row', gap: 10 }}>
    <TouchableOpacity
      style={styles.cartBtn}
      activeOpacity={0.8}
      onPress={user ? confirmLogout : () => navigation.navigate('Auth')}
    >
      <Feather name={user ? 'log-out' : 'log-in'} size={22} color={colors.dark} />
    </TouchableOpacity>
    <TouchableOpacity
      style={styles.cartBtn}
      activeOpacity={0.8}
      onPress={() => navigation.navigate('Cart')}
    >
      <Feather name="shopping-cart" size={22} color={colors.dark} />
      {totalItems > 0 && (
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{totalItems}</Text>
        </View>
      )}
    </TouchableOpacity>
  </View>
</View>

        <View style={styles.search}>
          <Feather name="search" size={20} color="#A9A4B8" />
          <TextInput
            placeholder="Search products..."
            placeholderTextColor="#A9A4B8"
            style={styles.searchInput}
          />
        </View>

        <MarqueeBanner text="20% OFF on Shopping Above Rs. 1,200 — Available Till 20 October" />

        <View style={styles.sectionRow}>
          <Text style={styles.sectionTitle}>Shop by Category</Text>
          <Text style={styles.sectionCount}>3 categories</Text>
        </View>

        {categories.map((c) => (
          <TouchableOpacity
            key={c.name}
            style={styles.card}
            activeOpacity={0.85}
            onPress={() => navigation.navigate(c.route)}
          >
            <View style={styles.cardImg}>
  {c.name === 'Accessories' ? (
    <Image
      source={require('../../assets/images/accessories.png')}
      style={styles.categoryImage}
      resizeMode="cover"
    />
  ) : c.name === 'Makeup' ? (
    <Image
       source={require('../../assets/images/makeup.png')}
      style={styles.categoryImage}
      resizeMode="cover"
    />
  ) : (
    <Image
      source={{
        uri: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400',
      }}
      style={styles.categoryImage}
      resizeMode="cover"
    />
  )}
</View>
            <View style={styles.cardText}>
              <Text style={styles.cardTitle}>{c.name}</Text>
              <Text style={styles.cardDesc}>{c.desc}</Text>
              <View style={[styles.chip, { backgroundColor: c.tint }]}>
                <Text style={[styles.chipText, { color: c.color }]}>Explore</Text>
              </View>
            </View>
            <View style={[styles.arrow, { backgroundColor: c.tint }]}>
              <Feather name="chevron-right" size={18} color={c.color} />
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  categoryImage: {
  width: '100%',
  height: '100%',
  borderRadius: 18,
},
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20, gap: 16 },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  welcome: { fontFamily: fonts.regular, fontSize: 13, color: colors.muted },
  title: { fontFamily: fonts.bold, fontSize: 26, color: colors.dark },
  cartBtn: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: colors.white,
    alignItems: 'center', justifyContent: 'center', elevation: 4,
  },
  badge: {
  position: 'absolute', top: -2, right: -2, minWidth: 18, height: 18, borderRadius: 9,
  backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4,
},
badgeText: { fontFamily: fonts.bold, fontSize: 10, color: colors.white },
  search: {
    flexDirection: 'row', alignItems: 'center', gap: 10, height: 50,
    backgroundColor: colors.white, borderRadius: 16, paddingHorizontal: 16, elevation: 3,
  },
  searchInput: { flex: 1, fontFamily: fonts.regular, fontSize: 14, color: colors.dark },
  sectionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sectionTitle: { fontFamily: fonts.semibold, fontSize: 18, color: colors.dark },
  sectionCount: { fontFamily: fonts.medium, fontSize: 12, color: colors.primary },
  card: {
    flexDirection: 'row', alignItems: 'center', gap: 14, padding: 12,
    backgroundColor: colors.white, borderRadius: 24, elevation: 4,
  },
  cardImg: { width: 92, height: 92, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  cardText: { flex: 1, gap: 4 },
  cardTitle: { fontFamily: fonts.semibold, fontSize: 18, color: colors.dark },
  cardDesc: { fontFamily: fonts.regular, fontSize: 12, color: colors.muted },
  chip: { alignSelf: 'flex-start', paddingVertical: 4, paddingHorizontal: 10, borderRadius: 10, marginTop: 2 },
  chipText: { fontFamily: fonts.semibold, fontSize: 11 },
  arrow: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
});