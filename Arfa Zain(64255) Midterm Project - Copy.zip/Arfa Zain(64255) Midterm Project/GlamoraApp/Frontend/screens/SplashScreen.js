import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { colors, fonts } from '../theme';

export default function SplashScreen({ navigation }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('MainTabs');
    }, 8000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <LinearGradient
      colors={['#F0567F', '#D6336C', '#4A1D6E']}
      style={styles.container}
    >
      <View style={styles.circleBig} />
      <View style={styles.circleSmall} />

      <View style={styles.logoBox}>
        <Feather name="shopping-bag" size={58} color={colors.primary} />
      </View>
      <Text style={styles.appName}>Glamora</Text>
      <Text style={styles.tagline}>Accessories  ·  Clothes  ·  Makeup</Text>

      <View style={styles.promo}>
        <Feather name="star" size={18} color={colors.dark} />
        <Text style={styles.promoText}>20% OFF — Limited Stock!</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  circleBig: {
    position: 'absolute', top: -90, left: -110, width: 320, height: 320,
    borderRadius: 160, backgroundColor: 'rgba(255,255,255,0.08)',
  },
  circleSmall: {
    position: 'absolute', bottom: 80, right: -60, width: 220, height: 220,
    borderRadius: 110, backgroundColor: 'rgba(255,255,255,0.10)',
  },
  logoBox: {
    width: 116, height: 116, borderRadius: 40, backgroundColor: colors.white,
    alignItems: 'center', justifyContent: 'center', marginBottom: 14, elevation: 8,
  },
  appName: { fontFamily: fonts.bold, fontSize: 40, color: colors.white },
  tagline: { fontFamily: fonts.regular, fontSize: 14, color: colors.white, marginTop: 4 },
  promo: {
    flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 36,
    backgroundColor: colors.gold, paddingVertical: 14, paddingHorizontal: 24,
    borderRadius: 32,
  },
  promoText: { fontFamily: fonts.semibold, fontSize: 15, color: colors.dark },
});