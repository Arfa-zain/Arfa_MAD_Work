import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { colors, fonts } from '../theme';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function Field({ label, icon, value, onChangeText, placeholder, secure, keyboardType }) {
  const [hidden, setHidden] = useState(!!secure);
  const [focus, setFocus] = useState(false);
  return (
    <View style={{ gap: 6 }}>
      <Text style={styles.label}>{label}</Text>
      <View style={[styles.input, focus && styles.inputFocus]}>
        <Feather name={icon} size={20} color={focus ? colors.primary : '#A9A4B8'} />
        <TextInput
          style={styles.inputText}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#A9A4B8"
          secureTextEntry={hidden}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType={keyboardType}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
        />
        {secure && (
          <TouchableOpacity onPress={() => setHidden(!hidden)}>
            <Feather name={hidden ? 'eye' : 'eye-off'} size={20} color="#A9A4B8" />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

export default function AuthScreen({ navigation, route }) {
  const insets = useSafeAreaInsets();
  const { login, signup } = useAuth();
  const { addToCart } = useCart();
  const pending = route.params?.pendingProduct;

  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const isLogin = mode === 'login';

  const switchMode = (m) => {
    setMode(m);
    setError('');
  };
  const finish = (message) => {
    setBusy(false);
    if (message) {
      setError(message);
      return;
    }
    // Login ke baad: jo product dabaya tha wo cart mein
    if (pending) {
      addToCart(pending);
      Alert.alert('Added to cart', pending.title);
    }
    navigation.goBack();
  };

  const handleSubmit = () => {
    setError('');
    if (!EMAIL_RE.test(email.trim())) return setError('Please enter a valid email.');
    if (password.length < 6) return setError('Password must be at least 6 characters.');
    if (!isLogin && password !== confirm) return setError('Passwords do not match.');

    setBusy(true);
    if (isLogin) login(email, password, finish);
    else signup(email, password, finish);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        style={styles.root}
        contentContainerStyle={{ flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient
          colors={['#F0567F', '#D6336C', '#5A1E78']}
          style={[styles.hero, { paddingTop: insets.top + 12 }]}
        >
          <TouchableOpacity style={[styles.back, { top: insets.top + 8 }]} onPress={() => navigation.goBack()}>
            <Feather name="arrow-left" size={20} color={colors.dark} />
          </TouchableOpacity>
          <View style={styles.logo}>
            <Feather name="shopping-bag" size={36} color={colors.primary} />
          </View>
          <Text style={styles.heroTitle}>{isLogin ? 'Welcome back!' : 'Create account'}</Text>
          <Text style={styles.heroSub}>
            {isLogin ? 'Login to add products to your cart' : 'Sign up to start shopping with Glamora'}
          </Text>
        </LinearGradient>

        <View style={styles.sheet}>
          <View style={styles.toggle}>
            {['login', 'signup'].map((m) => (
              <TouchableOpacity
                key={m}
                style={[styles.toggleBtn, mode === m && styles.toggleOn]}
                onPress={() => switchMode(m)}
              >
                <Text style={[styles.toggleText, mode === m && styles.toggleTextOn]}>
                  {m === 'login' ? 'Login' : 'Sign up'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Field
            label="Email" icon="mail" value={email} onChangeText={setEmail}
            placeholder="you@example.com" keyboardType="email-address"
          />
          <Field
            label="Password" icon="lock" value={password} onChangeText={setPassword}
            placeholder="At least 6 characters" secure
          />
          {!isLogin && (
            <Field
              label="Confirm password" icon="lock" value={confirm} onChangeText={setConfirm}
              placeholder="Re-enter password" secure
            />
          )}

          {!!error && <Text style={styles.error}>{error}</Text>}

          <TouchableOpacity style={styles.submit} activeOpacity={0.85} onPress={handleSubmit} disabled={busy}>
            {busy ? (
              <ActivityIndicator color={colors.white} />
            ) : (
              <Text style={styles.submitText}>{isLogin ? 'Login' : 'Create Account'}</Text>
            )}
          </TouchableOpacity>

          <View style={styles.footer}>
            <Text style={styles.footerText}>
              {isLogin ? "Don't have an account?" : 'Already have an account?'}
            </Text>
            <TouchableOpacity onPress={() => switchMode(isLogin ? 'signup' : 'login')}>
              <Text style={styles.footerLink}>{isLogin ? 'Sign up' : 'Login'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  hero: { alignItems: 'center', paddingBottom: 56, gap: 8 },
  back: {
    position: 'absolute', left: 20, width: 40, height: 40, borderRadius: 20,
    backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center',
  },
  logo: {
    width: 76, height: 76, borderRadius: 26, backgroundColor: colors.white,
    alignItems: 'center', justifyContent: 'center', marginTop: 24, elevation: 6,
  },
  heroTitle: { fontFamily: fonts.bold, fontSize: 26, color: colors.white },
  heroSub: { fontFamily: fonts.regular, fontSize: 13, color: colors.white },
  sheet: {
    flex: 1, marginTop: -30, backgroundColor: colors.white, borderTopLeftRadius: 32,
    borderTopRightRadius: 32, padding: 24, gap: 16,
  },
  toggle: { flexDirection: 'row', backgroundColor: '#F6E9EE', borderRadius: 18, padding: 4 },
  toggleBtn: { flex: 1, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  toggleOn: { backgroundColor: colors.white, elevation: 3 },
  toggleText: { fontFamily: fonts.medium, fontSize: 14, color: colors.muted },
  toggleTextOn: { fontFamily: fonts.semibold, color: colors.primary },
  label: { fontFamily: fonts.medium, fontSize: 12, color: colors.muted },
  input: {
    flexDirection: 'row', alignItems: 'center', gap: 12, height: 54, borderRadius: 16,
    borderWidth: 1, borderColor: '#EFD9E1', paddingHorizontal: 16, backgroundColor: colors.white,
  },
  inputFocus: { borderColor: colors.primary, borderWidth: 1.5 },
  inputText: { flex: 1, fontFamily: fonts.regular, fontSize: 14, color: colors.dark },
  error: { fontFamily: fonts.medium, fontSize: 12, color: '#D92D20' },
  submit: {
    height: 54, borderRadius: 27, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center',
  },
  submitText: { fontFamily: fonts.semibold, fontSize: 16, color: colors.white },
  footer: { flexDirection: 'row', justifyContent: 'center', gap: 6 },
  footerText: { fontFamily: fonts.regular, fontSize: 13, color: colors.muted },
  footerLink: { fontFamily: fonts.bold, fontSize: 13, color: colors.primary },
});