import React from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import ScreenHeader from '../components/ScreenHeader';
import AppImage from '../components/AppImage';
import { useCart } from '../context/CartContext';
import { formatPrice } from '../data/products';
import { colors, fonts } from '../theme';

const LIMIT = 1200;

export default function CartScreen({ navigation }) {
  const { items, increase, decrease, removeItem, clearCart, totalItems, subtotal } = useCart();

  // Cart empty
  if (items.length === 0) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <ScreenHeader title="My Cart" navigation={navigation} hideCart hideBack />
        <View style={styles.empty}>
          <View style={styles.emptyIcon}>
            <Feather name="shopping-cart" size={44} color={colors.primary} />
          </View>
          <Text style={styles.emptyTitle}>Your cart is empty</Text>
          <Text style={styles.emptySub}>Add some products to get started.</Text>
          <TouchableOpacity style={styles.primaryBtn} onPress={() => navigation.navigate('Home')}>
            <Text style={styles.primaryText}>Start Shopping</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const remaining = LIMIT - subtotal;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScreenHeader title="My Cart" navigation={navigation} hideCart hideBack />

      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View style={styles.topRow}>
            <Text style={styles.count}>
              {items.length} products · {totalItems} items
            </Text>
            <TouchableOpacity onPress={clearCart}>
              <Text style={styles.clear}>Clear all</Text>
            </TouchableOpacity>
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.item}>
            <View style={styles.imgBox}>
              <AppImage
                source={item.image}
                style={styles.img}
                resizeMode="contain"
                fallback={<Feather name="package" size={34} color={colors.primary} />}
              />
            </View>

            <View style={styles.info}>
              <View style={styles.nameRow}>
                <Text style={styles.name} numberOfLines={2}>{item.title}</Text>
                <TouchableOpacity style={styles.trash} onPress={() => removeItem(item.id)}>
                  <Feather name="trash-2" size={15} color={colors.primary} />
                </TouchableOpacity>
              </View>

              <Text style={styles.price}>{formatPrice(item.price)}</Text>

              <View style={styles.stepper}>
                <TouchableOpacity style={styles.stepBtn} onPress={() => decrease(item.id)}>
                  <Feather name="minus" size={14} color={colors.dark} />
                </TouchableOpacity>
                <Text style={styles.qty}>{item.qty}</Text>
                <TouchableOpacity style={[styles.stepBtn, styles.stepPlus]} onPress={() => increase(item.id)}>
                  <Feather name="plus" size={14} color={colors.white} />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
        ListFooterComponent={
          <View style={{ gap: 14 }}>
            {remaining > 0 ? (
              <View style={styles.hint}>
                <Feather name="tag" size={16} color="#B26A00" />
                <Text style={styles.hintText}>
                  Add {formatPrice(remaining)} more to get 20% OFF
                </Text>
              </View>
            ) : (
              <View style={[styles.hint, styles.hintGreen]}>
                <Feather name="check-circle" size={16} color="#177A4C" />
                <Text style={[styles.hintText, { color: '#177A4C' }]}>
                  20% discount will be applied at checkout
                </Text>
              </View>
            )}

            <View style={styles.total}>
              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Items total</Text>
                <Text style={styles.totalValue}>{formatPrice(subtotal)}</Text>
              </View>
              <View style={styles.totalRow}>
                <Text style={styles.totalBig}>Total amount</Text>
                <Text style={styles.totalBigValue}>{formatPrice(subtotal)}</Text>
              </View>
            </View>

            <TouchableOpacity
              style={styles.primaryBtn}
              activeOpacity={0.85}
              onPress={() => navigation.navigate('Checkout')}
            >
              <Text style={styles.primaryText}>Proceed to Checkout</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  list: { paddingHorizontal: 20, paddingBottom: 30, gap: 12 },
  topRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 2 },
  count: { fontFamily: fonts.medium, fontSize: 13, color: colors.muted },
  clear: { fontFamily: fonts.semibold, fontSize: 12, color: colors.primary },

  item: {
    flexDirection: 'row', gap: 12, padding: 12, backgroundColor: colors.white,
    borderRadius: 22, elevation: 4, alignItems: 'center',
  },
  imgBox: {
    width: 84, height: 84, borderRadius: 16, backgroundColor: colors.white,
    borderWidth: 1, borderColor: '#F3E7EC', alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
  },
  img: { width: '85%', height: '85%' },
  info: { flex: 1, gap: 6 },
  nameRow: { flexDirection: 'row', gap: 8, alignItems: 'flex-start' },
  name: { flex: 1, fontFamily: fonts.medium, fontSize: 13, lineHeight: 18, color: colors.dark },
  trash: {
    width: 28, height: 28, borderRadius: 14, backgroundColor: colors.soft,
    alignItems: 'center', justifyContent: 'center',
  },
  price: { fontFamily: fonts.bold, fontSize: 15, color: colors.primary },
  stepper: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  stepBtn: {
    width: 28, height: 28, borderRadius: 14, backgroundColor: '#F6E9EE',
    alignItems: 'center', justifyContent: 'center',
  },
  stepPlus: { backgroundColor: colors.primary },
  qty: { fontFamily: fonts.semibold, fontSize: 14, color: colors.dark, minWidth: 16, textAlign: 'center' },

  hint: {
    flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#FFF0D6',
    borderRadius: 16, paddingVertical: 12, paddingHorizontal: 14,
  },
  hintGreen: { backgroundColor: '#DDF3E8' },
  hintText: { flex: 1, fontFamily: fonts.medium, fontSize: 12, color: '#B26A00' },

  total: { backgroundColor: colors.white, borderRadius: 22, padding: 18, gap: 10, elevation: 4 },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontFamily: fonts.regular, fontSize: 13, color: colors.muted },
  totalValue: { fontFamily: fonts.medium, fontSize: 13, color: colors.dark },
  totalBig: { fontFamily: fonts.semibold, fontSize: 15, color: colors.dark },
  totalBigValue: { fontFamily: fonts.bold, fontSize: 20, color: colors.primary },

  primaryBtn: {
    height: 54, borderRadius: 27, backgroundColor: colors.primary,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32,
  },
  primaryText: { fontFamily: fonts.semibold, fontSize: 16, color: colors.white },

  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, padding: 30 },
  emptyIcon: {
    width: 96, height: 96, borderRadius: 48, backgroundColor: colors.soft,
    alignItems: 'center', justifyContent: 'center', marginBottom: 8,
  },
  emptyTitle: { fontFamily: fonts.semibold, fontSize: 20, color: colors.dark },
  emptySub: { fontFamily: fonts.regular, fontSize: 13, color: colors.muted, marginBottom: 12 },
});