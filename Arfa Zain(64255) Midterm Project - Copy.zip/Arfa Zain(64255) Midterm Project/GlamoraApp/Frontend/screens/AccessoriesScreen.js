import React from 'react';
import SubCategoryLayout from '../components/SubCategoryLayout';

const sections = [
  {
    label: 'For Him', gender: 'Male', tint: '#E4ECFF', color: '#3B6BD6',
    items: [
      { label: 'Purses / Wallets', icon: 'wallet-outline', slug: 'womens-bags', pick: 1 },
      { label: 'Watches', icon: 'watch-variant', slug: 'mens-watches', pick: 0 },
    ],
  },
  {
    label: 'For Her', gender: 'Female', tint: '#FDE4EC', color: '#D6336C',
    items: [
      { label: 'Jewellery', icon: 'diamond-stone', slug: 'womens-jewellery', pick: 0 },
      { label: 'Purses', icon: 'purse-outline', slug: 'womens-bags', pick: 0 },
    ],
  },
];

export default function AccessoriesScreen({ navigation }) {
  return (
    <SubCategoryLayout
      title="Accessories"
      bannerTitle="Complete your look"
      bannerSub="Watches, wallets & jewellery"
      sections={sections}
      navigation={navigation}
    />
  );
}