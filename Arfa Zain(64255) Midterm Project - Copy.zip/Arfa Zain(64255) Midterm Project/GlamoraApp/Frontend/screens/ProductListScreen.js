import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import ScreenHeader from '../components/ScreenHeader';
import ProductCard from '../components/ProductCard';
import LiveBadge from '../components/LiveBadge';
import useAddToCart from '../hooks/useAddToCart';
import { getProducts } from '../data/products';
import { loadForScreen, SOURCES } from '../data/api';
import { colors, fonts } from '../theme';

const SORTS = [
  { key: 'popular', label: 'Popular' },
  { key: 'price', label: 'Price: Low–High' },
  { key: 'rating', label: 'Top rated' },
];

export default function ProductListScreen({ route, navigation }) {
  const { category, gender, sub } = route.params;
  const key = `${category}|${gender}|${sub}`;
  const hasApi = !!SOURCES[key];
  const handleAdd = useAddToCart(navigation);

  const [sort, setSort] = useState('popular');
  const [apiItems, setApiItems] = useState([]);
  const [loading, setLoading] = useState(hasApi);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!hasApi) return;
    let active = true;
    setLoading(true);
    setFailed(false);
    loadForScreen(key, (err, items) => {
      if (!active) return;
      if (err) setFailed(true);
      else setApiItems(items || []);
      setLoading(false);
    });
    return () => { active = false; };
  }, [key]);

  const isLive = hasApi && !failed;

  const products = useMemo(() => {
    const base = isLive ? apiItems : getProducts(category, gender, sub);
    const list = [...base];
    if (sort === 'price') list.sort((a, b) => a.price - b.price);
    if (sort === 'rating') list.sort((a, b) => b.rating - a.rating);
    return list;
  }, [isLive, apiItems, category, gender, sub, sort]);

  const data = products.length % 2 ? [...products, { id: 'empty', empty: true }] : products;

  if (loading) {
    return (
      <SafeAreaView style={styles.safe}>
        <ScreenHeader title={sub} navigation={navigation} />
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.msg}>Loading products...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenHeader title={sub} navigation={navigation} />
      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={{ gap: 16 }}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View style={{ gap: 14 }}>
            {isLive && (
              <LiveBadge
                count={products.length}
                source={SOURCES[key].api === 'fake' ? 'fakestoreapi.com/products' : 'dummyjson.com/products'}
              />
            )}
            {failed && <Text style={styles.offline}>Offline — showing saved products</Text>}
            <View style={styles.chips}>
              {SORTS.map((s) => (
                <TouchableOpacity
                  key={s.key}
                  style={[styles.chip, sort === s.key && styles.chipOn]}
                  onPress={() => setSort(s.key)}
                >
                  <Text style={[styles.chipText, sort === s.key && styles.chipTextOn]}>{s.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.row}>
              <Text style={styles.heading}>
                {gender === 'Male' ? "Men's" : "Women's"} {sub}
              </Text>
              <Text style={styles.count}>{products.length} products</Text>
            </View>
          </View>
        }
        renderItem={({ item, index }) => (
          <ProductCard
            product={item}
            index={index}
            onPress={() => navigation.navigate('ProductDetail', { product: item })}
            onAdd={() => handleAdd(item)}
          />
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  list: { paddingHorizontal: 20, paddingBottom: 30, gap: 16 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  msg: { fontFamily: fonts.regular, fontSize: 13, color: colors.muted },
  offline: { fontFamily: fonts.medium, fontSize: 12, color: '#B26A00' },
  chips: { flexDirection: 'row', gap: 10, flexWrap: 'wrap' },
  chip: {
    paddingVertical: 8, paddingHorizontal: 16, borderRadius: 20,
    backgroundColor: colors.white, borderWidth: 1, borderColor: '#F0E1E7',
  },
  chipOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { fontFamily: fonts.medium, fontSize: 12, color: colors.muted },
  chipTextOn: { fontFamily: fonts.semibold, color: colors.white },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  heading: { fontFamily: fonts.semibold, fontSize: 16, color: colors.dark },
  count: { fontFamily: fonts.medium, fontSize: 12, color: colors.primary },
});