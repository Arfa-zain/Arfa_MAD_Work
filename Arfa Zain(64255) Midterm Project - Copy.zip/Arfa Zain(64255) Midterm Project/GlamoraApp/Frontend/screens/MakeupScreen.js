import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import ScreenHeader from '../components/ScreenHeader';
import ProductCard from '../components/ProductCard';
import LiveBadge from '../components/LiveBadge';
import useAddToCart from '../hooks/useAddToCart';
import { fetchProducts, API_MAP } from '../data/api';
import { colors, fonts } from '../theme';

export default function MakeupScreen({ navigation }) {
  const handleAdd = useAddToCart(navigation);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadProducts = useCallback(() => {
    setLoading(true);
    setError(null);
    fetchProducts((err, all) => {
      if (err) {
        setError(err.message || 'Something went wrong');
      } else {
        setProducts(all.filter((p) => p.apiCategory === API_MAP.Makeup));
      }
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  const data = products.length % 2 ? [...products, { id: 'empty', empty: true }] : products;

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenHeader title="Makeup" navigation={navigation} />

      {loading && (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.msg}>Loading products...</Text>
        </View>
      )}

      {!loading && error && (
        <View style={styles.center}>
          <Text style={styles.errTitle}>Could not load products</Text>
          <Text style={styles.msg}>{error}</Text>
          <TouchableOpacity style={styles.retry} onPress={loadProducts}>
            <Text style={styles.retryText}>Try again</Text>
          </TouchableOpacity>
        </View>
      )}

      {!loading && !error && (
        <FlatList
          data={data}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={{ gap: 16 }}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={<LiveBadge count={products.length} />}
          renderItem={({ item, index }) => (
            <ProductCard
              product={item}
              index={index}
              onPress={() => navigation.navigate('ProductDetail', { product: item })}
              onAdd={() => handleAdd(item)}
            />
          )}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  list: { paddingHorizontal: 20, paddingBottom: 30, gap: 16 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, padding: 30 },
  msg: { fontFamily: fonts.regular, fontSize: 13, color: colors.muted, textAlign: 'center' },
  errTitle: { fontFamily: fonts.semibold, fontSize: 16, color: colors.dark },
  retry: { marginTop: 8, backgroundColor: colors.primary, paddingVertical: 12, paddingHorizontal: 28, borderRadius: 24 },
  retryText: { fontFamily: fonts.semibold, fontSize: 14, color: colors.white },
});