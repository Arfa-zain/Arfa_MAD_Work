
import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useCart } from '../context/CartContext';
import { formatPrice } from '../data/products';
import { colors, fonts } from '../theme';

export default function CheckoutScreen({ navigation }) {
  const { items, subtotal, clearCart } = useCart();
  const discount = Math.round(subtotal * 0.20);
  const total = subtotal - discount;

  const placeOrder = () => {
    if (items.length === 0) {
      Alert.alert('Cart is empty', 'Please add products before checkout.');
      navigation.navigate('Home');
      return;
    }

    clearCart();
    navigation.replace('OrderPlaced', {
      total,
      itemCount: items.reduce((sum, item) => sum + item.qty, 0),
    });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Feather name="arrow-left" size={24} color={colors.dark} />
        </TouchableOpacity>
        <Text style={styles.heading}>Checkout</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.section}>Order Summary</Text>

        {items.map((item, index) => (
          <View key={`${item.id}-${index}`} style={styles.itemRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.itemName}>
                {item.title || item.name || 'Product'}
              </Text>
              <Text style={styles.muted}>Quantity: {item.qty}</Text>
            </View>
            <Text style={styles.itemPrice}>
              {formatPrice(item.price * item.qty)}
            </Text>
          </View>
        ))}

        <View style={styles.summary}>
          <View style={styles.row}>
            <Text style={styles.muted}>Subtotal</Text>
            <Text style={styles.value}>{formatPrice(subtotal)}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.discountLabel}>Discount (20%)</Text>
            <Text style={styles.discountValue}>−{formatPrice(discount)}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.row}>
            <Text style={styles.grandLabel}>Total to Pay</Text>
            <Text style={styles.grandTotal}>{formatPrice(total)}</Text>
          </View>
        </View>

        <View style={styles.notice}>
          <Feather name="tag" size={20} color={colors.primary} />
          <Text style={styles.noticeText}>
            Glamora discount: 20% off your order!
          </Text>
        </View>

        <Text style={styles.disclaimer}>
          Demo checkout only. No payment will be processed.
        </Text>
      </ScrollView>

      <View style={styles.bottom}>
        <View>
          <Text style={styles.muted}>Final amount</Text>
          <Text style={styles.grandTotal}>{formatPrice(total)}</Text>
        </View>
        <TouchableOpacity style={styles.button} onPress={placeOrder}>
          <Text style={styles.buttonText}>Place Order</Text>
          <Feather name="check-circle" size={18} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', padding: 20,
  },
  heading: { fontFamily: fonts.bold, fontSize: 22, color: colors.dark },
  content: { padding: 20, gap: 18, paddingBottom: 30 },
  section: { fontFamily: fonts.bold, fontSize: 18, color: colors.dark },
  itemRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: '#F0E1E7',
  },
  itemName: { fontFamily: fonts.semibold, fontSize: 14, color: colors.dark },
  itemPrice: { fontFamily: fonts.semibold, color: colors.dark },
  muted: { fontFamily: fonts.regular, color: colors.muted, fontSize: 13 },
  summary: { backgroundColor: colors.white, padding: 18, borderRadius: 18, gap: 16 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  value: { fontFamily: fonts.medium, color: colors.dark },
  discountLabel: { fontFamily: fonts.medium, color: '#177A4C' },
  discountValue: { fontFamily: fonts.semibold, color: '#177A4C' },
  divider: { height: 1, backgroundColor: '#F0E1E7' },
  grandLabel: { fontFamily: fonts.bold, color: colors.dark, fontSize: 15 },
  grandTotal: { fontFamily: fonts.bold, color: colors.primary, fontSize: 20 },
  notice: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    padding: 16, backgroundColor: colors.soft, borderRadius: 14,
  },
  noticeText: { flex: 1, fontFamily: fonts.medium, color: colors.primary, fontSize: 13 },
  disclaimer: { fontFamily: fonts.regular, fontSize: 12, color: colors.muted },
  bottom: {
    backgroundColor: colors.white, padding: 18, gap: 12,
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
  },
  button: {
    minHeight: 52, borderRadius: 26, backgroundColor: colors.primary,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
  },
  buttonText: { fontFamily: fonts.semibold, color: '#FFFFFF', fontSize: 15 },
});
