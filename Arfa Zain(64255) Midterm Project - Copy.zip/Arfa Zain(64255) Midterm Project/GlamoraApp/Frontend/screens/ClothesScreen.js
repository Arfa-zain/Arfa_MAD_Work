import React from 'react';
import SubCategoryLayout from '../components/SubCategoryLayout';

const sections = [
  {
    label: 'For Him', gender: 'Male', tint: '#E4ECFF', color: '#3B6BD6',
    items: [
      { label: 'Stitched', icon: 'tshirt-crew-outline' },
      { label: 'Unstitched', icon: 'content-cut' },
    ],
  },
  {
    label: 'For Her', gender: 'Female', tint: '#FDE4EC', color: '#D6336C',
    items: [
      { label: 'Stitched', icon: 'tshirt-crew-outline' },
      { label: 'Unstitched', icon: 'content-cut' },
    ],
  },
];

export default function ClothesScreen({ navigation }) {
  return (
    <SubCategoryLayout
      title="Clothes"
      bannerTitle="New season, new style"
      bannerSub="Stitched & unstitched collections"
      sections={sections}
      navigation={navigation}
    />
  );
}