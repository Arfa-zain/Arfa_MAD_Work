import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import AppImage from '../components/AppImage';
import useAddToCart from '../hooks/useAddToCart';
import { formatPrice } from '../data/products';
import { colors, fonts } from '../theme';

export default function ProductDetailScreen({ route, navigation }) {
  const { product } = route.params;
  const insets = useSafeAreaInsets();
  const handleAdd = useAddToCart(navigation);
  const fromApi = !!product.apiCategory;
  const stars = Math.round(product.rating || 0);

  const fallback = (
    <MaterialCommunityIcons name={product.icon || 'shopping-outline'} size={110} color={colors.primary} />
  );

  return (
    <View style={styles.root}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 130 }}>
        <View style={[styles.hero, { backgroundColor: fromApi ? colors.white : colors.soft }]}>
          <AppImage
            source={product.image}
            style={fromApi ? styles.heroContain : styles.heroCover}
            resizeMode={fromApi ? 'contain' : 'cover'}
            fallback={fallback}
          />
          <TouchableOpacity
            style={[styles.circleBtn, { top: insets.top + 8, left: 20 }]}
            onPress={() => navigation.goBack()}
            activeOpacity={0.8}
          >
            <Feather name="arrow-left" size={22} color={colors.dark} />
          </TouchableOpacity>
          <View style={[styles.circleBtn, { top: insets.top + 8, right: 20 }]}>
            <Feather name="heart" size={22} color={colors.primary} />
          </View>
        </View>

        <View style={styles.sheet}>
          {!!product.tag && (
            <View style={styles.tag}>
              <Text style={styles.tagText}>{product.tag}</Text>
            </View>
          )}
          <Text style={styles.title}>{product.title}</Text>

          <View style={styles.ratingRow}>
            {[1, 2, 3, 4, 5].map((n) => (
              <Feather key={n} name="star" size={16} color={n <= stars ? colors.gold : '#E4DDE8'} />
            ))}
            <Text style={styles.ratingText}>
              {Number(product.rating).toFixed(1)}
              {product.reviews ? `  (${product.reviews} reviews)` : ''}
            </Text>
          </View>

          <View style={styles.priceRow}>
            <Text style={styles.price}>{formatPrice(product.price)}</Text>
            <View style={styles.stock}>
              <Text style={styles.stockText}>In stock</Text>
            </View>
          </View>

          <Text style={styles.sectionTitle}>Description</Text>
          <Text style={styles.desc}>{product.description}</Text>
        </View>
      </ScrollView>

      <View style={[styles.bar, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity style={styles.addBtn} activeOpacity={0.85} onPress={() => handleAdd(product)}>
          <Feather name="shopping-cart" size={20} color={colors.white} />
          <Text style={styles.addText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.white },
  hero: { height: 360, alignItems: 'center', justifyContent: 'center' },
  heroContain: { width: '70%', height: '70%' },
  heroCover: { width: '100%', height: '100%' },
  circleBtn: {
    position: 'absolute', width: 44, height: 44, borderRadius: 22, backgroundColor: colors.white,
    alignItems: 'center', justifyContent: 'center', elevation: 5,
  },
  sheet: {
    marginTop: -30, backgroundColor: colors.white, borderTopLeftRadius: 32, borderTopRightRadius: 32,
    padding: 22, gap: 12,
  },
  tag: { alignSelf: 'flex-start', backgroundColor: colors.soft, borderRadius: 12, paddingVertical: 5, paddingHorizontal: 12 },
  tagText: { fontFamily: fonts.semibold, fontSize: 12, color: colors.primary, textTransform: 'capitalize' },
  title: { fontFamily: fonts.semibold, fontSize: 21, lineHeight: 29, color: colors.dark },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  ratingText: { fontFamily: fonts.medium, fontSize: 12, color: colors.muted, marginLeft: 6 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  price: { fontFamily: fonts.bold, fontSize: 28, color: colors.primary },
  stock: { backgroundColor: '#DDF3E8', borderRadius: 12, paddingVertical: 5, paddingHorizontal: 12 },
  stockText: { fontFamily: fonts.semibold, fontSize: 12, color: '#177A4C' },
  sectionTitle: { fontFamily: fonts.semibold, fontSize: 16, color: colors.dark, marginTop: 4 },
  desc: { fontFamily: fonts.regular, fontSize: 13, lineHeight: 21, color: colors.muted },
  bar: {
    position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: colors.white,
    paddingTop: 16, paddingHorizontal: 20, elevation: 12,
  },
  addBtn: {
    height: 54, borderRadius: 27, backgroundColor: colors.primary, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center', gap: 10,
  },
  addText: { fontFamily: fonts.semibold, fontSize: 16, color: colors.white },
});