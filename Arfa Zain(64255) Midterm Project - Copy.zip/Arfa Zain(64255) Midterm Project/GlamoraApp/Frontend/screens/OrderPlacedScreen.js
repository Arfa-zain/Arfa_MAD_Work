
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { formatPrice } from '../data/products';
import { colors, fonts } from '../theme';

export default function OrderPlacedScreen({ navigation, route }) {
  const total = route.params?.total ?? 0;
  const itemCount = route.params?.itemCount ?? 0;

  const goHome = () =>
  navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.content}>
        <View style={styles.iconCircle}>
          <Feather name="check" size={54} color="#FFFFFF" />
        </View>

        <Text style={styles.title}>Order Placed!</Text>
        <Text style={styles.subtitle}>
          Thank you for shopping with Glamora.
        </Text>

        <View style={styles.card}>
          <Text style={styles.label}>Order status</Text>
          <Text style={styles.status}>Confirmed (Demo)</Text>

          <View style={styles.divider} />

          <View style={styles.row}>
            <Text style={styles.label}>Items</Text>
            <Text style={styles.value}>{itemCount}</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Amount paid</Text>
            <Text style={styles.total}>{formatPrice(total)}</Text>
          </View>
        </View>

        <Text style={styles.note}>
          This is a demo order. No real payment or delivery has been arranged.
        </Text>

        <TouchableOpacity style={styles.button} onPress={goHome}>
          <Text style={styles.buttonText}>Continue Shopping</Text>
          <Feather name="arrow-right" size={18} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24, gap: 18 },
  iconCircle: {
    width: 100, height: 100, borderRadius: 50, backgroundColor: colors.primary,
    alignItems: 'center', justifyContent: 'center',
  },
  title: { fontFamily: fonts.bold, fontSize: 28, color: colors.dark },
  subtitle: { fontFamily: fonts.regular, fontSize: 14, color: colors.muted, textAlign: 'center' },
  card: { width: '100%', padding: 20, borderRadius: 20, backgroundColor: colors.white, gap: 14 },
  label: { fontFamily: fonts.regular, color: colors.muted, fontSize: 13 },
  status: { fontFamily: fonts.semibold, color: '#177A4C', fontSize: 16 },
  divider: { height: 1, backgroundColor: '#F0E1E7' },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  value: { fontFamily: fonts.semibold, color: colors.dark },
  total: { fontFamily: fonts.bold, color: colors.primary, fontSize: 18 },
  note: { fontFamily: fonts.regular, fontSize: 12, color: colors.muted, textAlign: 'center', lineHeight: 18 },
  button: {
    width: '100%', minHeight: 54, borderRadius: 27, backgroundColor: colors.primary,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
  },
  buttonText: { fontFamily: fonts.semibold, color: '#FFFFFF', fontSize: 15 },
});
