import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { colors, fonts } from '../theme';

export default function ProfileScreen({ navigation }) {
  const { user, logout } = useAuth();
  const { totalItems } = useCart();

  const confirmLogout = () =>
    Alert.alert('Logout', 'Do you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Logout', style: 'destructive', onPress: logout },
    ]);

  const rows = [
    { label: 'My Cart', icon: 'shopping-cart', note: totalItems + ' items', go: 'Cart' },
    { label: 'Accessories', icon: 'watch', go: 'Accessories' },
    { label: 'Clothes', icon: 'shopping-bag', go: 'Clothes' },
    { label: 'Makeup', icon: 'star', go: 'Makeup' },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <Text style={styles.header}>Profile</Text>

      <View style={styles.card}>
        <View style={styles.avatar}>
          {user ? (
            <Text style={styles.avatarText}>{user.email[0].toUpperCase()}</Text>
          ) : (
            <Feather name="user" size={34} color={colors.primary} />
          )}
        </View>
        <Text style={styles.email} numberOfLines={1}>
          {user ? user.email : 'Guest user'}
        </Text>
        <Text style={styles.status}>{user ? 'Logged in' : 'Login to add products to cart'}</Text>
      </View>

      <View style={styles.list}>
        {rows.map((r) => (
          <TouchableOpacity
            key={r.label}
            style={styles.row}
            activeOpacity={0.85}
            onPress={() => navigation.navigate(r.go)}
          >
            <View style={styles.rowIcon}>
              <Feather name={r.icon} size={18} color={colors.primary} />
            </View>
            <Text style={styles.rowText}>{r.label}</Text>
            {!!r.note && <Text style={styles.note}>{r.note}</Text>}
            <Feather name="chevron-right" size={18} color="#A9A4B8" />
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
        style={[styles.btn, user && styles.btnOutline]}
        activeOpacity={0.85}
        onPress={user ? confirmLogout : () => navigation.navigate('Auth')}
      >
        <Feather name={user ? 'log-out' : 'log-in'} size={18} color={user ? colors.primary : colors.white} />
        <Text style={[styles.btnText, user && { color: colors.primary }]}>
          {user ? 'Logout' : 'Login / Sign up'}
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg, paddingHorizontal: 20, gap: 18 },
  header: { fontFamily: fonts.bold, fontSize: 24, color: colors.dark, marginTop: 12 },
  card: {
    backgroundColor: colors.white, borderRadius: 24, padding: 22, alignItems: 'center',
    gap: 6, elevation: 4,
  },
  avatar: {
    width: 76, height: 76, borderRadius: 38, backgroundColor: colors.soft,
    alignItems: 'center', justifyContent: 'center', marginBottom: 6,
  },
  avatarText: { fontFamily: fonts.bold, fontSize: 30, color: colors.primary },
  email: { fontFamily: fonts.semibold, fontSize: 16, color: colors.dark },
  status: { fontFamily: fonts.regular, fontSize: 12, color: colors.muted },
  list: { backgroundColor: colors.white, borderRadius: 22, paddingVertical: 6, elevation: 4 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, paddingHorizontal: 16 },
  rowIcon: {
    width: 34, height: 34, borderRadius: 17, backgroundColor: colors.soft,
    alignItems: 'center', justifyContent: 'center',
  },
  rowText: { flex: 1, fontFamily: fonts.medium, fontSize: 14, color: colors.dark },
  note: { fontFamily: fonts.medium, fontSize: 12, color: colors.muted },
  btn: {
    height: 54, borderRadius: 27, backgroundColor: colors.primary, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center', gap: 10,
  },
  btnOutline: { backgroundColor: colors.white, borderWidth: 1.5, borderColor: colors.primary },
  btnText: { fontFamily: fonts.semibold, fontSize: 15, color: colors.white },
});