export const colors = {
  primary: '#D6336C',
  dark: '#1F1A2E',
  bg: '#FFF7F9',
  muted: '#7A7589',
  soft: '#FDE4EC',
  gold: '#F5A524',
  white: '#FFFFFF',
  green: '#1E9E63',
};

export const fonts = {
  regular: 'Poppins_400Regular',
  medium: 'Poppins_500Medium',
  semibold: 'Poppins_600SemiBold',
  bold: 'Poppins_700Bold',
};