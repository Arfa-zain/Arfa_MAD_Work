import { Alert } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

export default function useAddToCart(navigation) {
  const { user } = useAuth();
  const { addToCart } = useCart();

  return (product) => {
    if (!user) {
      navigation.navigate('Auth', { pendingProduct: product });
      return;
    }
    addToCart(product);
    Alert.alert('Added to cart', product.title, [
      { text: 'Continue' },
      { text: 'View Cart', onPress: () => navigation.navigate('MainTabs', { screen: 'Cart' }) },
    ]);
  };
}