import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AuthContext = createContext(null);
const USERS_KEY = 'glamora_users';
const SESSION_KEY = 'glamora_session';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

// Load session from AsyncStorage on mount
  useEffect(() => {
    AsyncStorage.getItem(SESSION_KEY, (err, saved) => {
      if (!err && saved) setUser(JSON.parse(saved));
      setLoading(false);
    });
  }, []);

  const getUsers = (done) => {
    AsyncStorage.getItem(USERS_KEY, (err, raw) => {
      done(raw ? JSON.parse(raw) : {});
    });
  };

  const startSession = (email, done) => {
    const session = { email };
    AsyncStorage.setItem(SESSION_KEY, JSON.stringify(session), () => {
      setUser(session);
      done(null);
    });
  };

  // done(null) done('message') = error
  const signup = (email, password, done) => {
    setTimeout(() => {
      getUsers((users) => {
        const key = email.trim().toLowerCase();
        if (users[key]) {
          done('This email is already registered. Please login.');
          return;
        }
        users[key] = password;
        AsyncStorage.setItem(USERS_KEY, JSON.stringify(users), () => {
          startSession(key, done);
        });
      });
    }, 500); // demo delay
  };

  const login = (email, password, done) => {
    setTimeout(() => {
      getUsers((users) => {
        const key = email.trim().toLowerCase();
        if (!users[key]) {
          done('No account found. Please sign up first.');
          return;
        }
        if (users[key] !== password) {
          done('Incorrect password.');
          return;
        }
        startSession(key, done);
      });
    }, 500);
  };

  const logout = () => {
    AsyncStorage.removeItem(SESSION_KEY, () => {
      setUser(null);
    });
  };

  return (
    <AuthContext.Provider value={{ user, loading, signup, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);