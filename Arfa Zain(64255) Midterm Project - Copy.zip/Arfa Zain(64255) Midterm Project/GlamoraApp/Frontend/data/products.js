
const make = (prefix, icon, tag, items) =>
  items.map(([title, price, rating, description], i) => ({
    id: `${prefix}-${i + 1}`,
    title,
    price,
    rating,
    description,
    icon,
    tag,
  }));

// Online images are automatically assigned based on product category.
const KEYWORDS = {
  'Accessories|Male|Purses / Wallets': 'wallet,leather',
  'Accessories|Male|Watches': 'wristwatch',
  'Accessories|Female|Jewellery': 'jewellery,necklace',
  'Accessories|Female|Purses': 'handbag',
  'Clothes|Male|Stitched': 'men,shirt',
  'Clothes|Male|Unstitched': 'fabric,cloth',
  'Clothes|Female|Stitched': 'dress,women',
  'Clothes|Female|Unstitched': 'fabric,textile',
};

export const catalog = {
  'Accessories|Male|Purses / Wallets': make(
    'amw',
    'wallet-outline',
    "Men's Wallets",
    [
      ['Classic Leather Bifold Wallet', 1299, 4.5, 'Genuine leather bifold wallet with multiple card slots and a coin pocket.'],
      ['Slim Cardholder Wallet', 899, 4.3, 'Minimal slim cardholder that fits easily in your front pocket.'],
      ['Zip Around Travel Wallet', 1799, 4.6, 'Spacious zip-around wallet for cash, cards, and travel documents.'],
      ['Premium Brown Long Wallet', 2199, 4.8, 'Long premium wallet with a rich finish and RFID protection.'],
    ]
  ),

  'Accessories|Male|Watches': make(
    'amwt',
    'watch-variant',
    "Men's Watches",
    [
      ['Classic Leather Strap Watch', 2499, 4.6, 'Timeless analog watch with a genuine leather strap.'],
      ['Minimal Steel Mesh Watch', 3199, 4.4, 'Slim stainless steel mesh watch with a clean dial.'],
      ['Sport Chronograph Watch', 1899, 4.2, 'Water-resistant chronograph built for active days.'],
      ['Black Edition Analog Watch', 2799, 4.8, 'All-black analog watch with a scratch-resistant glass.'],
    ]
  ),

  'Accessories|Female|Jewellery': make(
    'afj',
    'diamond-stone',
    "Women's Jewellery",
    [
      ['Gold Plated Pendant Necklace', 1499, 4.7, 'Delicate gold plated necklace with a sparkling pendant.'],
      ['Pearl Drop Earrings', 999, 4.5, 'Elegant pearl drop earrings for everyday and party wear.'],
      ['Crystal Charm Bracelet', 1299, 4.4, 'Adjustable bracelet with shimmering crystal charms.'],
      ['Rose Gold Stackable Rings', 899, 4.6, 'Set of three rose gold rings that stack beautifully.'],
    ]
  ),

  'Accessories|Female|Purses': make(
    'afp',
    'purse-outline',
    "Women's Purses",
    [
      ['Quilted Shoulder Bag', 2499, 4.7, 'Soft quilted shoulder bag with a gold chain strap.'],
      ['Mini Crossbody Purse', 1699, 4.5, 'Compact crossbody purse that holds all your essentials.'],
      ['Classic Tote Handbag', 2999, 4.6, 'Roomy tote handbag with a sturdy handle and inner zip pocket.'],
      ['Clutch With Wrist Strap', 1199, 4.3, 'Stylish clutch for weddings and evening events.'],
    ]
  ),

  'Clothes|Male|Stitched': make(
    'cms',
    'tshirt-crew-outline',
    "Men's Stitched",
    [
      ['Cotton Kurta Shalwar', 2199, 4.5, 'Comfortable stitched cotton kurta shalwar for daily wear.'],
      ['Slim Fit Casual Shirt', 1499, 4.4, 'Soft slim fit shirt that works for office and outings.'],
      ['Premium Waistcoat', 2599, 4.7, 'Formal waistcoat to complete your wedding and party look.'],
      ['Printed Polo T-Shirt', 899, 4.2, 'Breathable cotton polo with a modern print.'],
    ]
  ),

  'Clothes|Male|Unstitched': make(
    'cmu',
    'content-cut',
    "Men's Unstitched",
    [
      ['Wash & Wear Suit Fabric', 1999, 4.4, 'Easy-care wash and wear fabric, 4 meters per suit.'],
      ['Cotton Summer Fabric', 1699, 4.3, 'Light cotton fabric perfect for hot weather.'],
      ['Premium Winter Wool Fabric', 3299, 4.8, 'Warm wool blend fabric with a smooth finish.'],
      ['Plain Cambric Fabric', 1299, 4.2, 'Classic plain cambric fabric in solid colours.'],
    ]
  ),

  'Clothes|Female|Stitched': make(
    'cfs',
    'tshirt-crew-outline',
    "Women's Stitched",
    [
      ['Embroidered Lawn Kurti', 1899, 4.6, 'Stitched lawn kurti with detailed neckline embroidery.'],
      ['Printed 2-Piece Suit', 2499, 4.5, 'Ready-to-wear printed shirt and trousers set.'],
      ['Chiffon Party Frock', 3799, 4.8, 'Flowy chiffon frock with a beautiful lace border.'],
      ['Casual Cotton Co-ord Set', 1699, 4.3, 'Matching cotton top and trouser set for relaxed days.'],
    ]
  ),

  'Clothes|Female|Unstitched': make(
    'cfu',
    'content-cut',
    "Women's Unstitched",
    [
      ['Printed Lawn 3-Piece', 2299, 4.6, 'Lawn shirt, dupatta, and trouser fabric, ready to stitch.'],
      ['Embroidered Chiffon Fabric', 3499, 4.7, 'Fine chiffon with all-over embroidery for special occasions.'],
      ['Khaddar Winter 3-Piece', 2799, 4.4, 'Warm khaddar fabric in a trendy digital print.'],
      ['Cotton Slub Plain Fabric', 1399, 4.2, 'Soft slub cotton, great for simple everyday suits.'],
    ]
  ),
};

export const getProducts = (category, gender, sub) => {
  const key = `${category}|${gender}|${sub}`;
  const list = catalog[key] || [];
  const keywords = (KEYWORDS[key] || 'fashion,product').replace(/,/g, ',');

  return list.map((p, i) => ({
    ...p,
    image: `https://loremflickr.com/400/400/${keywords}?lock=${i + 1}`,
  }));
};

export const formatPrice = (n) =>
  'Rs. ' + String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
