const FAKESTORE_URL = 'https://fakestoreapi.com/products';
const DUMMY_URL = 'https://dummyjson.com/products/category/';

let fakeCache = null;
const dummyCache = {};

// Callback request: done(error, data)
const getJSON = (url, done) => {
  fetch(url)
    .then((response) => {
      if (!response.ok) throw new Error('Server error: ' + response.status);
      return response.json();
    })
    .then((data) => done(null, data))
    .catch((err) => done(new Error(err.message || 'No internet connection')));
};

// ---- fakestoreapi ----
export const fetchProducts = (done) => {
  if (fakeCache) {
    done(null, fakeCache);
    return;
  }
  getJSON(FAKESTORE_URL, (err, data) => {
    if (err) {
      done(err);
      return;
    }
    fakeCache = data.map((p) => ({
      id: String(p.id),
      title: p.title,
      price: Math.round(p.price * 10), // API price x 10 => Rs.
      rating: p.rating ? p.rating.rate : 0,
      reviews: p.rating ? p.rating.count : 0,
      description: p.description,
      image: p.image,
      tag: p.category,
      apiCategory: p.category,
    }));
    done(null, fakeCache);
  });
};

// ---- dummyjson ----
export const fetchDummy = (slug, done) => {
  if (dummyCache[slug]) {
    done(null, dummyCache[slug]);
    return;
  }
  getJSON(DUMMY_URL + slug, (err, data) => {
    if (err) {
      done(err);
      return;
    }
    dummyCache[slug] = data.products.map((p) => ({
      id: 'd-' + p.id,
      title: p.title,
      price: Math.round(p.price * 10),
      rating: p.rating || 0,
      reviews: p.reviews ? p.reviews.length : 0,
      description: p.description,
      image: p.thumbnail,
      tag: p.category,
      apiCategory: 'dummyjson',
    }));
    done(null, dummyCache[slug]);
  });
};

// Makeup screen (fakestore)
export const API_MAP = { Makeup: 'jewelery' };

// Product list screens: API / category
export const SOURCES = {
  'Accessories|Male|Watches': { api: 'dummy', slug: 'mens-watches' },
  'Accessories|Male|Purses / Wallets': { api: 'dummy', slug: 'womens-bags' },
  'Accessories|Female|Jewellery': { api: 'dummy', slug: 'womens-jewellery' },
  'Accessories|Female|Purses': { api: 'dummy', slug: 'womens-bags' },
  'Clothes|Male|Stitched': { api: 'dummy', slug: 'mens-shirts' },
  'Clothes|Female|Stitched': { api: 'dummy', slug: 'womens-dresses' },
  'Clothes|Male|Unstitched': { api: 'fake', category: "men's clothing" },
  'Clothes|Female|Unstitched': { api: 'fake', category: "women's clothing" },
};

export const loadForScreen = (key, done) => {
  const s = SOURCES[key];
  if (!s) {
    done(null, null);
    return;
  }
  if (s.api === 'fake') {
    fetchProducts((err, all) => {
      if (err) {
        done(err);
        return;
      }
      done(null, all.filter((p) => p.apiCategory === s.category));
    });
    return;
  }
  fetchDummy(s.slug, done);
};