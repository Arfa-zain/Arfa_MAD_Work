import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useCart } from '../context/CartContext';
import { colors, fonts } from '../theme';

export default function ScreenHeader({ title, navigation, hideCart, hideBack }) {
  const { totalItems } = useCart();
  return (
    <View style={styles.header}>
      {hideBack ? (
        <View style={{ width: 44 }} />
      ) : (
        <TouchableOpacity style={styles.btn} activeOpacity={0.8} onPress={() => navigation.goBack()}>
          <Feather name="arrow-left" size={22} color={colors.dark} />
        </TouchableOpacity>
      )}
      <Text style={styles.title}>{title}</Text>
      {hideCart ? (
        <View style={{ width: 44 }} />
      ) : (
        <TouchableOpacity
          style={styles.btn}
          activeOpacity={0.8}
          onPress={() => navigation.navigate('MainTabs', { screen: 'Cart' })}
        >
          <Feather name="shopping-cart" size={22} color={colors.dark} />
          {totalItems > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{totalItems}</Text>
            </View>
          )}
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: 8, paddingBottom: 12,
  },
  btn: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: colors.white,
    alignItems: 'center', justifyContent: 'center', elevation: 4,
  },
  title: { fontFamily: fonts.semibold, fontSize: 20, color: colors.dark },
  badge: {
    position: 'absolute', top: -2, right: -2, minWidth: 18, height: 18, borderRadius: 9,
    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4,
  },
  badgeText: { fontFamily: fonts.bold, fontSize: 10, color: colors.white },
});