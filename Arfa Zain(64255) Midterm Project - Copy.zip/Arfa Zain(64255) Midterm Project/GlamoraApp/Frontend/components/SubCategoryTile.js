import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { colors, fonts } from '../theme';

export default function SubCategoryTile({ label, icon, tint, color, onPress }) {
  return (
    <TouchableOpacity style={styles.tile} activeOpacity={0.85} onPress={onPress}>
      <View style={[styles.img, { backgroundColor: tint }]}>
        <MaterialCommunityIcons name={icon} size={48} color={color} />
      </View>
      <View style={styles.row}>
        <Text style={styles.label} numberOfLines={1}>{label}</Text>
        <View style={[styles.arrow, { backgroundColor: tint }]}>
          <Feather name="chevron-right" size={14} color={color} />
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  tile: {
    flex: 1, backgroundColor: colors.white, borderRadius: 22, padding: 14,
    gap: 14, elevation: 4,
  },
  img: { height: 92, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 6 },
  label: { flex: 1, fontFamily: fonts.semibold, fontSize: 14, color: colors.dark },
  arrow: { width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
});