import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, Easing } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { colors, fonts } from '../theme';

export default function MarqueeBanner({ text }) {
  const x = useRef(new Animated.Value(10)).current;
  const [textWidth, setTextWidth] = useState(0);
  const message = text + '        •        ';

  useEffect(() => {
    if (!textWidth) return;
    x.setValue(0);
    const animation = Animated.loop(
      Animated.timing(x, {
        toValue: -textWidth,
        duration: textWidth * 18,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    animation.start();
    return () => animation.stop();
  }, [textWidth]);

  return (
    <View style={styles.banner}>
      <Feather name="tag" size={18} color={colors.gold} style={styles.icon} />
      <View style={styles.track}>
        <Animated.View style={[styles.row, { transform: [{ translateX: x }] }]}>
          <Text
            style={styles.text}
            onLayout={(e) => setTextWidth(e.nativeEvent.layout.width)}
          >
            {message}
          </Text>
          <Text style={styles.text}>{message}</Text>
          <Text style={styles.text}>{message}</Text>
        </Animated.View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  banner: {
    height: 44, borderRadius: 14, backgroundColor: colors.dark,
    flexDirection: 'row', alignItems: 'center', paddingLeft: 14, overflow: 'hidden',
  },
  icon: { marginRight: 10 },
  track: { flex: 1, height: 44, overflow: 'hidden' },
  row: { position: 'absolute', left: 0, top: 0, height: 44, flexDirection: 'row', alignItems: 'center' },
  text: { fontFamily: fonts.medium, fontSize: 13, color: colors.white },
});