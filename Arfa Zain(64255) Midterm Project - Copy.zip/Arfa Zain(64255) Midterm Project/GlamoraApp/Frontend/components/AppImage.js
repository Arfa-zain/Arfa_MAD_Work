import React, { useState } from 'react';
import { Image } from 'react-native';


export default function AppImage({ source, style, resizeMode = 'cover', fallback = null }) {
  const [failed, setFailed] = useState(false);
  if (!source || failed) return fallback;
  const src = typeof source === 'string' ? { uri: source } : source;
  return (
    <Image source={src} style={style} resizeMode={resizeMode} onError={() => setFailed(true)} />
  );
}