import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, fonts } from '../theme';

export default function LiveBadge({ count, source = 'fakestoreapi.com/products' }) {
  return (
    <View style={styles.live}>
      <View style={styles.dot} />
      <Text style={styles.text}>Live data · {source} ({count})</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  live: {
    flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#DDF3E8',
    borderRadius: 14, paddingVertical: 8, paddingHorizontal: 14,
  },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.green },
  text: { fontFamily: fonts.medium, fontSize: 12, color: '#177A4C' },
});