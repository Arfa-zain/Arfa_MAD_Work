import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import ScreenHeader from './ScreenHeader';
import SubCategoryTile from './SubCategoryTile';
import { fetchDummy } from '../data/api';
import { colors, fonts } from '../theme';

export default function SubCategoryLayout({
  title, bannerTitle, bannerSub, sections, navigation,
}) {
  const [lists, setLists] = useState({}); // slug -> API products

  // Tiles images through API fetch, only once per slug. If already fetched, use that.
  useEffect(() => {
    let active = true;
    const slugs = [];
    sections.forEach((s) =>
      s.items.forEach((i) => {
        if (i.slug && !slugs.includes(i.slug)) slugs.push(i.slug);
      })
    );
    slugs.forEach((slug) => {
      fetchDummy(slug, (err, list) => {
        if (!active || err || !list) return;
        setLists((prev) => ({ ...prev, [slug]: list }));
      });
    });
    return () => { active = false; };
  }, []);

  // Get image for a tile. If the tile has an image, use that. Otherwise, if it has a slug, fetch the list for that slug and use the image of the first pick (or 0th pick).
  const imageFor = (it) => {
    if (it.image) return it.image;
    const list = lists[it.slug];
    const p = list && list[it.pick || 0];
    return p ? p.image : null;
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenHeader title={title} navigation={navigation} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <LinearGradient
          colors={['#D6336C', '#6C2A8E']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.banner}
        >
          <View style={{ flex: 1 }}>
            <Text style={styles.bannerTitle}>{bannerTitle}</Text>
            <Text style={styles.bannerSub}>{bannerSub}</Text>
          </View>
          <Feather name="star" size={56} color="rgba(255,255,255,0.35)" />
        </LinearGradient>

        {sections.map((sec) => (
          <View key={sec.label} style={styles.section}>
            <View style={styles.labelRow}>
              <View style={[styles.dot, { backgroundColor: sec.tint }]}>
                <Feather name="user" size={16} color={sec.color} />
              </View>
              <Text style={styles.sectionTitle}>{sec.label}</Text>
            </View>
            <View style={styles.tiles}>
              {sec.items.map((it) => (
                <SubCategoryTile
                  key={it.label}
                  label={it.label}
                  icon={it.icon}
                  image={imageFor(it)}
                  tint={sec.tint}
                  color={sec.color}
                  onPress={() =>
                    navigation.navigate('ProductList', {
                      title: `${sec.gender} ${it.label}`,
                      category: title,
                      gender: sec.gender,
                      sub: it.label,
                    })
                  }
                />
              ))}
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { paddingHorizontal: 20, paddingBottom: 30, gap: 20 },
  banner: {
    height: 96, borderRadius: 24, paddingHorizontal: 22,
    flexDirection: 'row', alignItems: 'center',
  },
  bannerTitle: { fontFamily: fonts.bold, fontSize: 19, color: colors.white },
  bannerSub: { fontFamily: fonts.regular, fontSize: 12, color: colors.white, marginTop: 2 },
  section: { gap: 12 },
  labelRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  dot: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  sectionTitle: { fontFamily: fonts.semibold, fontSize: 18, color: colors.dark },
  tiles: { flexDirection: 'row', gap: 16 },
});