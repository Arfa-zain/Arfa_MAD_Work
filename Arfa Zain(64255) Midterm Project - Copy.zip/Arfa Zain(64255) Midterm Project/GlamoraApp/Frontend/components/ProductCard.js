import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import AppImage from './AppImage';
import { formatPrice } from '../data/products';
import { colors, fonts } from '../theme';

const tones = [
  ['#FDE4EC', '#D6336C'],
  ['#E8E2FF', '#6C4BD6'],
  ['#FFF0D6', '#E08A00'],
  ['#DDF3E8', '#1E9E63'],
];

export default function ProductCard({ product, index = 0, onPress, onAdd }) {
  if (product.empty) return <View style={{ flex: 1 }} />;
  const [tint, color] = tones[index % 4];
  const fromApi = !!product.apiCategory; // API images: white background, contain

  const iconFallback = (
    <MaterialCommunityIcons name={product.icon || 'shopping-outline'} size={52} color={color} />
  );

  return (
    <TouchableOpacity style={styles.card} activeOpacity={0.9} onPress={onPress}>
      <View style={[styles.img, { backgroundColor: product.image && fromApi ? colors.white : tint }]}>
        <AppImage
          source={product.image}
          style={fromApi ? styles.contain : styles.cover}
          resizeMode={fromApi ? 'contain' : 'cover'}
          fallback={iconFallback}
        />
        <View style={styles.heart}>
          <Feather name="heart" size={16} color={colors.primary} />
        </View>
      </View>

      <View style={styles.info}>
        <Text style={styles.title} numberOfLines={2}>{product.title}</Text>
        <View style={styles.ratingRow}>
          <Feather name="star" size={13} color={colors.gold} />
          <Text style={styles.rating}>{Number(product.rating).toFixed(1)}</Text>
        </View>
        <View style={styles.priceRow}>
          <Text style={styles.price}>{formatPrice(product.price)}</Text>
          <TouchableOpacity style={styles.addBtn} activeOpacity={0.8} onPress={onAdd}>
            <Feather name="plus" size={16} color={colors.white} />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { flex: 1, backgroundColor: colors.white, borderRadius: 20, overflow: 'hidden', elevation: 4 },
  img: { height: 140, alignItems: 'center', justifyContent: 'center' },
  cover: { width: '100%', height: '100%' },
  contain: { width: '80%', height: '80%' },
  heart: {
    position: 'absolute', top: 10, right: 10, width: 30, height: 30, borderRadius: 15,
    backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center',
  },
  info: { padding: 12, gap: 6 },
  title: { fontFamily: fonts.medium, fontSize: 13, lineHeight: 18, color: colors.dark, minHeight: 36 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  rating: { fontFamily: fonts.medium, fontSize: 12, color: colors.muted },
  priceRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  price: { fontFamily: fonts.bold, fontSize: 14, color: colors.primary },
  addBtn: {
    width: 30, height: 30, borderRadius: 15, backgroundColor: colors.primary,
    alignItems: 'center', justifyContent: 'center',
  },
});